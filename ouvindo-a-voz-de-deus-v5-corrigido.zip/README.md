# Ouvindo a Voz de Deus — Estudo Bíblico

Versão estática para GitHub Pages, sem IA e sem chave de API.

## Estrutura

- `index.html` — página principal
- `assets/app.js` — interface, navegação, progresso e popup bíblico
- `assets/data.js` — conteúdo dos 27 estudos
- `assets/biblia.js` — parser das referências e conexão com a Free Use Bible API / HelloAO
- `assets/styles.css` — estilos
- `assets/images/` — 27 ilustrações locais em SVG

## Bíblia

O popup usa somente uma versão em português: **Bíblia Livre (`porbr2018`)**. A API HelloAO documenta o endpoint simplificado por capítulo no formato `https://bible.helloao.org/api/{translation}/{book}/{chapter}.simple.json`.

Não há seletor de versões, token, chave ou configuração no navegador.

## Imagens

As imagens dos estudos são arquivos SVG locais. Isso evita dependência do Wikimedia Commons, CORS, hotlink e APIs externas para a interface.

## Publicação no GitHub Pages

Envie para o repositório mantendo exatamente a pasta `assets/images/`. Depois faça um recarregamento forçado no navegador (`Ctrl + F5`).

## Importante

A pasta não precisa de Google Apps Script, `Code.gs`, `config.js` ou qualquer chave de IA.
